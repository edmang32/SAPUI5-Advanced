// @ts-nocheck
sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    
    return Controller.extend("ns.Employees.controller.App",{
        onInit: function () {
            
        }
    });
});